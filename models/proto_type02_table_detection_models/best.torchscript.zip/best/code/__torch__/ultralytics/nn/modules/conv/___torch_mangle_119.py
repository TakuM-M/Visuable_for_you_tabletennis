class Conv(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  conv : __torch__.torch.nn.modules.conv.___torch_mangle_117.Conv2d
  act : __torch__.torch.nn.modules.linear.___torch_mangle_118.Identity
  def forward(self: __torch__.ultralytics.nn.modules.conv.___torch_mangle_119.Conv,
    input: Tensor) -> Tensor:
    act = self.act
    conv = self.conv
    _0 = (conv).forward(input, )
    _1 = (act).forward()
    return _0
