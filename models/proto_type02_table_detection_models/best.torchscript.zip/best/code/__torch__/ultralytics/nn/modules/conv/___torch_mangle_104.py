class Conv(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  conv : __torch__.torch.nn.modules.conv.___torch_mangle_103.Conv2d
  act : __torch__.torch.nn.modules.linear.Identity
  def forward(self: __torch__.ultralytics.nn.modules.conv.___torch_mangle_104.Conv,
    argument_1: Tensor) -> Tensor:
    act = self.act
    conv = self.conv
    _0 = (conv).forward(argument_1, )
    _1 = (act).forward()
    return _0
