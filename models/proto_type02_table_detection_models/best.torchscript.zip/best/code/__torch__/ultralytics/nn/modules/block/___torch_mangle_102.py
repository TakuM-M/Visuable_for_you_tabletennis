class C3k2(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  cv1 : __torch__.ultralytics.nn.modules.conv.___torch_mangle_72.Conv
  cv2 : __torch__.ultralytics.nn.modules.conv.___torch_mangle_75.Conv
  m : __torch__.torch.nn.modules.container.___torch_mangle_101.ModuleList
  def forward(self: __torch__.ultralytics.nn.modules.block.___torch_mangle_102.C3k2,
    argument_1: __torch__.torch.nn.modules.activation.___torch_mangle_286.SiLU,
    argument_2: Tensor) -> Tensor:
    cv2 = self.cv2
    m = self.m
    _0 = getattr(m, "0")
    cv1 = self.cv1
    _1 = (cv1).forward(argument_1, argument_2, )
    _2 = torch.split_with_sizes(_1, [128, 128], 1)
    _3, input, = _2
    _4 = [_3, input, (_0).forward(argument_1, input, )]
    input0 = torch.cat(_4, 1)
    return (cv2).forward(argument_1, input0, )
