class Sequential(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  __annotations__["0"] = __torch__.ultralytics.nn.modules.block.PSABlock
  def forward(self: __torch__.torch.nn.modules.container.___torch_mangle_130.Sequential,
    argument_1: __torch__.torch.nn.modules.activation.___torch_mangle_286.SiLU,
    x: Tensor) -> Tensor:
    _0 = getattr(self, "0")
    return (_0).forward(argument_1, x, )
