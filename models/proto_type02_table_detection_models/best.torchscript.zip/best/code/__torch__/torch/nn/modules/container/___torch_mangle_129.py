class Sequential(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  __annotations__["0"] = __torch__.ultralytics.nn.modules.conv.___torch_mangle_125.Conv
  __annotations__["1"] = __torch__.ultralytics.nn.modules.conv.___torch_mangle_128.Conv
  def forward(self: __torch__.torch.nn.modules.container.___torch_mangle_129.Sequential,
    argument_1: __torch__.torch.nn.modules.activation.___torch_mangle_286.SiLU,
    input: Tensor) -> Tensor:
    _1 = getattr(self, "1")
    _0 = getattr(self, "0")
    _2 = (_1).forward((_0).forward(argument_1, input, ), )
    return _2
